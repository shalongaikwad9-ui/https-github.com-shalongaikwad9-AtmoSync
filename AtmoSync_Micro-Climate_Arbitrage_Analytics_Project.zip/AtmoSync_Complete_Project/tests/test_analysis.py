import pandas as pd
from src.analysis import location_summary, pairwise_comparison

def sample_data():
    return pd.DataFrame({
        "location": ["Pune", "Pune", "Hinjawadi"],
        "temperature": [30, 32, 28],
        "humidity": [60, 64, 70],
    })

def test_location_summary():
    result = location_summary(sample_data())
    pune = result[result["location"] == "Pune"].iloc[0]
    assert pune["avg_temperature"] == 31
    assert pune["avg_humidity"] == 62
    assert pune["records"] == 2

def test_pairwise_comparison():
    summary = location_summary(sample_data())
    result = pairwise_comparison(summary)
    assert len(result) == 1
    assert result.iloc[0]["temperature_difference"] == 3
    assert result.iloc[0]["humidity_difference"] == 8
