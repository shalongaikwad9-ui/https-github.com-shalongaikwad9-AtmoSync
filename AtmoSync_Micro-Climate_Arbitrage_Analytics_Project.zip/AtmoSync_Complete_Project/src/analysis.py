"""Pandas analysis helpers for AtmoSync."""
from pathlib import Path
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = PROJECT_ROOT / "data" / "weather_data.csv"
DATA_DIR = PROJECT_ROOT / "data"

NUMERIC_COLUMNS = [
    "temperature", "humidity", "precipitation",
    "wind_speed", "cloud_cover"
]

def load_weather_data(path=DATA_FILE) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        return pd.DataFrame()
    df = pd.read_csv(path)
    if df.empty:
        return df
    df.columns = df.columns.str.strip()
    required = {"location", "temperature", "humidity"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"CSV is missing required columns: {sorted(missing)}")
    for col in NUMERIC_COLUMNS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df["location"] = df["location"].astype(str).str.strip()
    df = df.dropna(subset=["location", "temperature", "humidity"])
    if "time" in df.columns:
        df["time"] = pd.to_datetime(df["time"], errors="coerce")
    return df

def location_summary(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()
    aggregations = {
        "avg_temperature": ("temperature", "mean"),
        "min_temperature": ("temperature", "min"),
        "max_temperature": ("temperature", "max"),
        "avg_humidity": ("humidity", "mean"),
        "min_humidity": ("humidity", "min"),
        "max_humidity": ("humidity", "max"),
        "records": ("location", "count"),
    }
    for source, target in [
        ("precipitation", "avg_precipitation"),
        ("wind_speed", "avg_wind_speed"),
        ("cloud_cover", "avg_cloud_cover"),
    ]:
        if source in df.columns:
            aggregations[target] = (source, "mean")
    return df.groupby("location").agg(**aggregations).round(2).reset_index()

def pairwise_comparison(summary: pd.DataFrame) -> pd.DataFrame:
    rows = []
    if summary.empty:
        return pd.DataFrame(columns=[
            "location_1", "location_2",
            "temperature_difference", "humidity_difference"
        ])
    for i in range(len(summary)):
        for j in range(i + 1, len(summary)):
            a, b = summary.iloc[i], summary.iloc[j]
            rows.append({
                "location_1": a["location"],
                "location_2": b["location"],
                "temperature_difference": round(abs(
                    a["avg_temperature"] - b["avg_temperature"]), 2),
                "humidity_difference": round(abs(
                    a["avg_humidity"] - b["avg_humidity"]), 2),
            })
    return pd.DataFrame(rows)

def save_reports(df: pd.DataFrame) -> dict:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if df.empty:
        raise ValueError("No valid data available to analyse.")
    summary = location_summary(df)
    comparisons = pairwise_comparison(summary)
    overall = df[["temperature", "humidity"]].agg(
        ["mean", "min", "max", "std"]
    ).round(2)
    paths = {
        "cleaned": DATA_DIR / "cleaned_weather_data.csv",
        "summary": DATA_DIR / "location_analysis.csv",
        "comparison": DATA_DIR / "location_comparison.csv",
        "overall": DATA_DIR / "overall_statistics.csv",
    }
    df.to_csv(paths["cleaned"], index=False)
    summary.to_csv(paths["summary"], index=False)
    comparisons.to_csv(paths["comparison"], index=False)
    overall.to_csv(paths["overall"])
    return paths

if __name__ == "__main__":
    data = load_weather_data()
    if data.empty:
        raise SystemExit("No data found. Run: python -m src.collector")
    report_paths = save_reports(data)
    summary = location_summary(data)
    print("\nLOCATION ANALYSIS")
    print(summary.to_string(index=False))
    print("\nPAIRWISE COMPARISON")
    print(pairwise_comparison(summary).to_string(index=False))
    print("\nHottest average location:", summary.loc[
        summary["avg_temperature"].idxmax(), "location"])
    print("Coolest average location:", summary.loc[
        summary["avg_temperature"].idxmin(), "location"])
    print("\nReports saved:")
    for label, path in report_paths.items():
        print(f"- {label}: {path}")
